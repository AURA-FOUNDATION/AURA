import SwiftUI
import PhotosUI
import Combine
import UIKit

// MARK: - 3. ROOT VIEW
struct ContentView: View {
    @StateObject var engine = AuraEngine()
    @State private var appState: AppFlow = .splash
    
    enum AppFlow {
        case splash
        case welcome
        case main
    }
    
    var body: some View {
        ZStack {
            AppTheme.bg.ignoresSafeArea()
            
            switch appState {
            case .splash:
                SplashScreen {
                    withAnimation {
                        appState = .welcome
                    }
                }
                
            case .welcome:
                WelcomeScreen {
                    withAnimation {
                        appState = .main
                    }
                }
                .transition(.opacity)
                
            case .main:
                MainTabLayout(engine: engine)
                    .transition(.opacity)
            }
        }
        .preferredColorScheme(.light)
    }
}

// MARK: - 4. SPLASH SCREEN
struct SplashScreen: View {
    var onFinish: () -> Void
    @State private var opacity = 0.0
    
    var body: some View {
        ZStack {
            AppTheme.bg.ignoresSafeArea()
            
            Text("A U R A")
                .font(.system(size: 60, weight: .bold, design: .serif))
                .foregroundColor(AppTheme.primary)
                .opacity(opacity)
                .scaleEffect(opacity)
        }
        .onAppear {
            withAnimation(.easeOut(duration: 1.0)) {
                opacity = 1.0
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                onFinish()
            }
        }
    }
}

// MARK: - 5. WELCOME SCREEN
struct WelcomeScreen: View {
    var onStart: () -> Void
    
    var body: some View {
        ZStack {
            AppTheme.bg.ignoresSafeArea()
            
            VStack(spacing: 30) {
                Spacer()
                
                Image(systemName: "cabinet")
                    .font(.system(size: 80))
                    .foregroundColor(AppTheme.primary.opacity(0.9))
                
                Text("Your Digital Closet")
                    .font(.title2)
                    .foregroundColor(AppTheme.primary)
                
                Spacer()
                
                Button(action: onStart) {
                    Text("Enter Closet")
                        .fontWeight(.bold)
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .frame(height: 56)
                        .background(AppTheme.primary)
                        .cornerRadius(16)
                }
                .padding(30)
            }
        }
    }
}

// MARK: - 6. MAIN LAYOUT (NATIVE TAB BAR)
struct MainTabLayout: View {
    @ObservedObject var engine: AuraEngine
    @State private var selectedTab = 0
    
    var body: some View {
        ZStack {
            AppTheme.bg.ignoresSafeArea()
            
            TabView(selection: $selectedTab) {
                MixerHomeView(engine: engine, selectedTab: $selectedTab)
                    .tag(0)
                    .tabItem {
                        Image(systemName: "tshirt")
                        Text("Matching")
                    }
                
                ClosetView(engine: engine)
                    .tag(1)
                    .tabItem {
                        Image(systemName: "cabinet")
                        Text("Closet")
                    }
                
                SavedLooksView(engine: engine)
                    .tag(2)
                    .tabItem {
                        Image(systemName: "bookmark.fill")
                        Text("Saved")
                    }
            }
        }
    }
}

// MARK: - 7. MIXER HOME VIEW
struct MixerHomeView: View {
    @ObservedObject var engine: AuraEngine
    @Binding var selectedTab: Int
    @State private var showSimulation = false
    
    var body: some View {
        ZStack {
            VStack(spacing: 0) {
                // Header
                HStack {
                    Text("Mix & Match")
                        .font(.system(size: 28, weight: .bold))
                        .foregroundColor(AppTheme.primary)
                    Spacer()
                }
                .padding(.horizontal, 24)
                .padding(.top, 20)
                .padding(.bottom, 10)
                
                if engine.items.isEmpty {
                    EmptyStateView()
                } else {
                    GeometryReader { geo in
                        VStack(spacing: 12) {
                            CarouselSection(
                                title: "TOPS",
                                items: engine.getItems(for: .top),
                                height: geo.size.height * 0.33,
                                selectionIndex: $engine.topIndex
                            )
                            CarouselSection(
                                title: "BOTTOMS",
                                items: engine.getItems(for: .bottom),
                                height: geo.size.height * 0.33,
                                selectionIndex: $engine.bottomIndex
                            )
                            CarouselSection(
                                title: "SHOES",
                                items: engine.getItems(for: .shoes),
                                height: geo.size.height * 0.20,
                                selectionIndex: $engine.shoeIndex
                            )
                        }
                    }
                    .padding(.top, 10)
                    .padding(.bottom, 60)
                }
            }
            
            // دکمه Visualize
            if !engine.items.isEmpty {
                VStack {
                    Spacer()
                    HStack {
                        Spacer()
                        Button(action: { showSimulation = true }) {
                            HStack(spacing: 8) {
                                Image(systemName: "wand.and.stars")
                                    .font(.system(size: 16, weight: .bold))
                                Text("Visualize")
                                    .font(.system(size: 14, weight: .bold))
                            }
                            .foregroundColor(.white)
                            .padding(.vertical, 12)
                            .padding(.horizontal, 20)
                            .background(
                                Capsule()
                                    .fill(Color.black)
                            )
                        }
                        .padding(.trailing, 24)
                        .padding(.bottom, 20)
                    }
                }
            }
        }
        .sheet(isPresented: $showSimulation) {
            SimulationResultView(engine: engine, selectedTab: $selectedTab)
        }
    }
}

// MARK: - 8. SIMULATION VIEW
struct SimulationResultView: View {
    @ObservedObject var engine: AuraEngine
    @Binding var selectedTab: Int
    @Environment(\.dismiss) var dismiss
    @State private var scale: CGFloat = 0.95
    
    var body: some View {
        ZStack {
            // Background gradient
            LinearGradient(
                gradient: Gradient(colors: [
                    AppTheme.bg,
                    AppTheme.bg.opacity(0.95)
                ]),
                startPoint: .top,
                endPoint: .bottom
            )
            .ignoresSafeArea()
            
            VStack(spacing: 0) {
                // Minimal drag indicator
                Capsule()
                    .fill(Color.gray.opacity(0.2))
                    .frame(width: 36, height: 4)
                    .padding(.top, 12)
                    .padding(.bottom, 8)
                
                // Elegant title
                Text("Your Look")
                    .font(.system(size: 20, weight: .light, design: .serif))
                    .foregroundColor(AppTheme.primary.opacity(0.8))
                    .tracking(2)
                    .padding(.top, 8)
                
                Spacer()
                
                // Luxurious card design
                ZStack {
                    // Subtle shadow layer
                    RoundedRectangle(cornerRadius: 32)
                        .fill(Color.white)
                        .shadow(color: Color.black.opacity(0.06), radius: 30, x: 0, y: 15)
                        .shadow(color: Color.black.opacity(0.03), radius: 10, x: 0, y: 5)
                        .padding(.horizontal, 20)
                        .frame(height: 500)
                    
                    // Main content card
                    RoundedRectangle(cornerRadius: 32)
                        .fill(Color.white)
                        .overlay(
                            RoundedRectangle(cornerRadius: 32)
                                .stroke(
                                    LinearGradient(
                                        gradient: Gradient(colors: [
                                            Color.white.opacity(0.8),
                                            AppTheme.primary.opacity(0.05)
                                        ]),
                                        startPoint: .topLeading,
                                        endPoint: .bottomTrailing
                                    ),
                                    lineWidth: 1
                                )
                        )
                        .padding(.horizontal, 20)
                        .frame(height: 500)
                    
                    // Clothing items
                    VStack(spacing: 0) {
                        if let top = engine.getCurrentTop() {
                            Image(uiImage: top.image)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 200)
                                .padding(.top, 20)
                                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                        }
                        
                        if let bottom = engine.getCurrentBottom() {
                            Image(uiImage: bottom.image)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 200)
                                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                        }
                        
                        if let shoes = engine.getCurrentShoes() {
                            Image(uiImage: shoes.image)
                                .resizable()
                                .scaledToFit()
                                .frame(height: 100)
                                .padding(.bottom, 20)
                                .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                        }
                    }
                    .padding(.horizontal, 30)
                }
                .scaleEffect(scale)
                .onAppear {
                    withAnimation(.spring(response: 0.6, dampingFraction: 0.8)) {
                        scale = 1.0
                    }
                }
                
                Spacer()
                
                // Save and Done buttons
                HStack(spacing: 12) {
                    Button(action: {
                        engine.saveCurrentLook()
                        dismiss()
                        DispatchQueue.main.asyncAfter(deadline: .now() + 0.3) {
                            selectedTab = 2
                        }
                    }) {
                        Text("Save")
                            .font(.system(size: 16, weight: .medium, design: .default))
                            .foregroundColor(AppTheme.primary)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(Color.white)
                                    .overlay(
                                        RoundedRectangle(cornerRadius: 16)
                                            .stroke(AppTheme.primary, lineWidth: 2)
                                    )
                            )
                    }
                    
                    Button(action: { dismiss() }) {
                        Text("Done")
                            .font(.system(size: 16, weight: .medium, design: .default))
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .fill(AppTheme.primary)
                            )
                            .shadow(color: AppTheme.primary.opacity(0.3), radius: 8, x: 0, y: 4)
                    }
                }
                .padding(.horizontal, 24)
                .padding(.bottom, 32)
            }
        }
    }
}

// MARK: - 9. CLOSET VIEW
struct ClosetView: View {
    @ObservedObject var engine: AuraEngine
    let columns = [
        GridItem(.flexible()),
        GridItem(.flexible()),
        GridItem(.flexible())
    ]
    
    @State private var selectedItem: ClothingItem?
    @State private var editingCategory: ClothCategory = .top
    @State private var showAddSheet = false
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("My Closet")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(AppTheme.primary)
                Spacer()
                Button(action: { showAddSheet = true }) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 28))
                        .foregroundColor(AppTheme.primary)
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 20)
            
            ScrollView {
                VStack(spacing: 30) {
                    ForEach(ClothCategory.allCases, id: \.self) { category in
                        let items = engine.getItems(for: category)
                        
                        VStack(alignment: .leading, spacing: 15) {
                            HStack {
                                Image(systemName: iconFor(category))
                                Text(category.rawValue.uppercased())
                                    .font(.subheadline)
                                    .fontWeight(.bold)
                                Spacer()
                                Text("\(items.count)")
                                    .font(.caption)
                                    .padding(.horizontal, 8)
                                    .padding(.vertical, 4)
                                    .background(Color.gray.opacity(0.1))
                                    .clipShape(Capsule())
                            }
                            .foregroundColor(AppTheme.primary)
                            .padding(.horizontal, 24)
                            
                            if items.isEmpty {
                                Text("No items")
                                    .font(.caption)
                                    .foregroundColor(.gray)
                                    .padding(.leading, 24)
                            } else {
                                LazyVGrid(columns: columns, spacing: 15) {
                                    ForEach(items) { item in
                                        Image(uiImage: item.image)
                                            .resizable()
                                            .scaledToFill()
                                            .frame(height: 100)
                                            .clipShape(RoundedRectangle(cornerRadius: 16))
                                            .overlay(
                                                RoundedRectangle(cornerRadius: 16)
                                                    .stroke(Color.black, lineWidth: 1.5)
                                            )
                                            .clipped()
                                            .onTapGesture {
                                                selectedItem = item
                                                editingCategory = item.category
                                            }
                                    }
                                }
                                .padding(.horizontal, 24)
                            }
                        }
                    }
                }
                .padding(.bottom, 50)
            }
        }
        .sheet(item: $selectedItem) { item in
            ClosetItemSheet(
                item: item,
                selectedCategory: $editingCategory,
                onChangeCategory: { newCat in
                    engine.changeCategory(for: item, to: newCat)
                },
                onDelete: {
                    engine.deleteItem(item)
                },
                onDone: {
                    selectedItem = nil
                }
            )
        }
        .sheet(isPresented: $showAddSheet) {
            AddGarmentSheet(engine: engine)
        }
    }
    
    func iconFor(_ cat: ClothCategory) -> String {
        switch cat {
        case .top: return "tshirt"
        case .bottom: return "rectangle.fill"
        case .shoes: return "shoe"
        }
    }
}

// MARK: - 10. CAROUSEL & EMPTY STATE
struct CarouselSection: View {
    let title: String
    let items: [ClothingItem]
    let height: CGFloat
    @Binding var selectionIndex: Int
    
    var body: some View {
        VStack(spacing: 5) {
            if items.isEmpty {
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.white)
                    VStack {
                        Image(systemName: "hanger")
                            .foregroundColor(.gray.opacity(0.3))
                        Text("No \(title)")
                            .font(.caption)
                            .foregroundColor(.gray)
                    }
                }
                .frame(height: height)
                .padding(.horizontal, 24)
            } else {
                TabView(selection: $selectionIndex) {
                    ForEach(0..<items.count, id: \.self) { index in
                        Image(uiImage: items[index].image)
                            .resizable()
                            .scaledToFit()
                            .padding(10)
                            .frame(maxWidth: .infinity, maxHeight: .infinity)
                            .background(Color.white)
                            .cornerRadius(20)
                            .shadow(color: Color.black.opacity(0.05),
                                    radius: 8, x: 0, y: 4)
                            .padding(.horizontal, 24)
                            .padding(.bottom, 5)
                            .tag(index)
                    }
                }
                .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                .frame(height: height)
                
                HStack(spacing: 4) {
                    ForEach(0..<items.count, id: \.self) { index in
                        Circle()
                            .fill(selectionIndex == index ? AppTheme.primary : Color.gray.opacity(0.3))
                            .frame(width: 5, height: 5)
                            .scaleEffect(selectionIndex == index ? 1.2 : 1.0)
                            .animation(.spring(), value: selectionIndex)
                    }
                }
            }
        }
    }
}

struct EmptyStateView: View {
    var body: some View {
        VStack(spacing: 15) {
            Spacer()
            Image(systemName: "archivebox")
                .font(.system(size: 50))
                .foregroundColor(.gray.opacity(0.3))
            Text("Closet Empty")
                .font(.headline)
                .foregroundColor(.gray)
            Text("Tap + to add clothes")
                .font(.caption)
                .foregroundColor(.gray.opacity(0.7))
            Spacer()
        }
    }
}

// MARK: - 11. ADD SHEET
struct AddGarmentSheet: View {
    @ObservedObject var engine: AuraEngine
    @Environment(\.dismiss) var dismiss
    @State private var selectedItem: PhotosPickerItem? = nil
    @State private var selectedImage: UIImage? = nil
    @State private var category: ClothCategory = .top
    @State private var showCamera = false
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 15) {
                        ForEach(ClothCategory.allCases, id: \.self) { cat in
                            VStack {
                                ZStack {
                                    Circle()
                                        .fill(category == cat ? AppTheme.primary : Color.gray.opacity(0.1))
                                        .frame(width: 60, height: 60)
                                    Image(systemName: iconFor(cat))
                                        .foregroundColor(category == cat ? .white : .black)
                                }
                                .onTapGesture {
                                    withAnimation {
                                        category = cat
                                    }
                                }
                                Text(cat.rawValue)
                                    .font(.caption)
                            }
                        }
                    }
                    .padding()
                }
                
                // پیش‌نمایش عکس انتخاب‌شده
                ZStack {
                    if let img = selectedImage {
                        Image(uiImage: img)
                            .resizable()
                            .scaledToFit()
                            .frame(height: 250)
                            .cornerRadius(12)
                    } else {
                        RoundedRectangle(cornerRadius: 12)
                            .stroke(style: StrokeStyle(lineWidth: 2, dash: [5]))
                            .foregroundColor(.gray)
                            .frame(height: 250)
                            .overlay(
                                Text("No image selected")
                                    .foregroundColor(.gray)
                            )
                    }
                }
                .padding(.horizontal)
                
                // انتخاب منبع عکس: گالری یا دوربین
                VStack(spacing: 8) {
                    Text("Choose photo source")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                    
                    HStack(spacing: 12) {
                        PhotosPicker(selection: $selectedItem, matching: .images) {
                            HStack {
                                Image(systemName: "photo.on.rectangle")
                                Text("Gallery")
                                    .bold()
                            }
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(Color.black)
                            .cornerRadius(12)
                        }
                        
                        Button {
                            showCamera = true
                        } label: {
                            HStack {
                                Image(systemName: "camera")
                                Text("Camera")
                                    .bold()
                            }
                            .foregroundColor(.black)
                            .frame(maxWidth: .infinity)
                            .frame(height: 44)
                            .background(Color.gray.opacity(0.15))
                            .cornerRadius(12)
                        }
                    }
                    .padding(.horizontal)
                }
                .onChange(of: selectedItem) { newItem in
                    Task {
                        if let data = try? await newItem?.loadTransferable(type: Data.self),
                           let uiImage = UIImage(data: data) {
                            selectedImage = uiImage
                        }
                    }
                }
                
                Spacer()
                
                Button(action: {
                    if let img = selectedImage {
                        engine.addItem(image: img, category: category)
                        dismiss()
                    }
                }) {
                    Text("Save Item")
                        .bold()
                        .foregroundColor(.white)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(selectedImage == nil ? Color.gray : AppTheme.primary)
                        .cornerRadius(12)
                }
                .disabled(selectedImage == nil)
                .padding()
            }
            .navigationTitle("Add New Item")
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
        }
        .sheet(isPresented: $showCamera) {
            CameraImagePicker { image in
                selectedImage = image
            }
        }
    }
    
    func iconFor(_ cat: ClothCategory) -> String {
        switch cat {
        case .top: return "tshirt"
        case .bottom: return "rectangle.fill"
        case .shoes: return "shoe"
        }
    }
}

// MARK: - SAVED LOOKS VIEW
struct SavedLooksView: View {
    @ObservedObject var engine: AuraEngine
    @State private var selectedLook: SavedLook?
    @State private var showEditSheet = false
    
    var body: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Saved Looks")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundColor(AppTheme.primary)
                Spacer()
            }
            .padding(.horizontal, 24)
            .padding(.top, 20)
            .padding(.bottom, 20)
            
            if engine.savedLooks.isEmpty {
                VStack(spacing: 15) {
                    Spacer()
                    Image(systemName: "bookmark")
                        .font(.system(size: 50))
                        .foregroundColor(.gray.opacity(0.3))
                    Text("No Saved Looks")
                        .font(.headline)
                        .foregroundColor(.gray)
                    Text("Save your favorite combinations")
                        .font(.caption)
                        .foregroundColor(.gray.opacity(0.7))
                    Spacer()
                }
            } else {
                ScrollView {
                    LazyVGrid(columns: [
                        GridItem(.flexible(), spacing: 15),
                        GridItem(.flexible(), spacing: 15)
                    ], spacing: 15) {
                        ForEach(engine.savedLooks) { look in
                            SavedLookCard(look: look, engine: engine) {
                                selectedLook = look
                                showEditSheet = true
                            }
                        }
                    }
                    .padding(.horizontal, 24)
                    .padding(.bottom, 50)
                }
            }
        }
        .sheet(item: $selectedLook) { look in
            EditSavedLookSheet(look: look, engine: engine) {
                selectedLook = nil
            }
        }
    }
}

struct SavedLookCard: View {
    let look: SavedLook
    @ObservedObject var engine: AuraEngine
    let onTap: () -> Void
    
    var topItem: ClothingItem? {
        guard let id = look.topItemId else { return nil }
        return engine.getItem(by: id)
    }
    
    var bottomItem: ClothingItem? {
        guard let id = look.bottomItemId else { return nil }
        return engine.getItem(by: id)
    }
    
    var shoesItem: ClothingItem? {
        guard let id = look.shoesItemId else { return nil }
        return engine.getItem(by: id)
    }
    
    var hasAnyItem: Bool {
        topItem != nil || bottomItem != nil || shoesItem != nil
    }
    
    var body: some View {
        Button(action: onTap) {
            VStack(spacing: 0) {
                ZStack {
                    RoundedRectangle(cornerRadius: 20)
                        .fill(Color.white)
                        .shadow(color: Color.black.opacity(0.05), radius: 8, x: 0, y: 4)
                    
                    if hasAnyItem {
                        VStack(spacing: 0) {
                            if let top = topItem {
                                Image(uiImage: top.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 80)
                            }
                            if let bottom = bottomItem {
                                Image(uiImage: bottom.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 80)
                            }
                            if let shoes = shoesItem {
                                Image(uiImage: shoes.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 50)
                            }
                        }
                        .padding(8)
                    } else {
                        VStack(spacing: 8) {
                            Image(systemName: "photo")
                                .font(.system(size: 40))
                                .foregroundColor(.gray.opacity(0.3))
                            Text("Item removed")
                                .font(.caption)
                                .foregroundColor(.gray.opacity(0.5))
                        }
                    }
                }
                .frame(height: 200)
                
                HStack {
                    Text("Edit")
                        .font(.caption)
                        .foregroundColor(AppTheme.primary)
                    Spacer()
                    Button(action: {
                        engine.deleteSavedLook(look)
                    }) {
                        Image(systemName: "trash")
                            .font(.caption)
                            .foregroundColor(.red)
                    }
                }
                .padding(.horizontal, 8)
                .padding(.top, 4)
            }
        }
        .buttonStyle(PlainButtonStyle())
    }
}

struct EditSavedLookSheet: View {
    let look: SavedLook
    @ObservedObject var engine: AuraEngine
    var onDismiss: () -> Void
    @Environment(\.dismiss) private var dismiss
    
    @State private var selectedTopId: UUID?
    @State private var selectedBottomId: UUID?
    @State private var selectedShoesId: UUID?
    
    var body: some View {
        NavigationView {
            ZStack {
                AppTheme.bg.ignoresSafeArea()
                
                VStack(spacing: 20) {
                    // Preview
                    ZStack {
                        RoundedRectangle(cornerRadius: 24)
                            .fill(Color.white)
                            .shadow(color: Color.black.opacity(0.05), radius: 10, x: 0, y: 5)
                            .frame(height: 300)
                        
                        VStack(spacing: 0) {
                            if let topId = selectedTopId, let top = engine.getItem(by: topId) {
                                Image(uiImage: top.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 120)
                            }
                            if let bottomId = selectedBottomId, let bottom = engine.getItem(by: bottomId) {
                                Image(uiImage: bottom.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 120)
                            }
                            if let shoesId = selectedShoesId, let shoes = engine.getItem(by: shoesId) {
                                Image(uiImage: shoes.image)
                                    .resizable()
                                    .scaledToFit()
                                    .frame(height: 60)
                            }
                        }
                        .padding()
                    }
                    .padding(.horizontal)
                    
                    // Category selectors
                    ScrollView {
                        VStack(spacing: 20) {
                            CategorySelector(
                                title: "Top",
                                items: engine.getItems(for: .top),
                                selectedId: $selectedTopId
                            )
                            
                            CategorySelector(
                                title: "Bottom",
                                items: engine.getItems(for: .bottom),
                                selectedId: $selectedBottomId
                            )
                            
                            CategorySelector(
                                title: "Shoes",
                                items: engine.getItems(for: .shoes),
                                selectedId: $selectedShoesId
                            )
                        }
                        .padding()
                    }
                    
                    Spacer()
                    
                    Button(action: {
                        engine.updateSavedLook(look, topItemId: selectedTopId, bottomItemId: selectedBottomId, shoesItemId: selectedShoesId)
                        onDismiss()
                        dismiss()
                    }) {
                        Text("Save Changes")
                            .font(.headline)
                            .foregroundColor(.white)
                            .frame(maxWidth: .infinity)
                            .frame(height: 52)
                            .background(AppTheme.primary)
                            .cornerRadius(16)
                    }
                    .padding()
                }
            }
            .navigationTitle("Edit Look")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Cancel") {
                        dismiss()
                    }
                }
            }
            .onAppear {
                selectedTopId = look.topItemId
                selectedBottomId = look.bottomItemId
                selectedShoesId = look.shoesItemId
            }
        }
    }
}

struct CategorySelector: View {
    let title: String
    let items: [ClothingItem]
    @Binding var selectedId: UUID?
    
    var body: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text(title)
                .font(.headline)
                .foregroundColor(AppTheme.primary)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack(spacing: 12) {
                    ForEach(items) { item in
                        Button(action: {
                            selectedId = item.id
                        }) {
                            Image(uiImage: item.image)
                                .resizable()
                                .scaledToFill()
                                .frame(width: 80, height: 80)
                                .clipShape(RoundedRectangle(cornerRadius: 12))
                                .overlay(
                                    RoundedRectangle(cornerRadius: 12)
                                        .stroke(selectedId == item.id ? AppTheme.primary : Color.clear, lineWidth: 3)
                                )
                        }
                    }
                }
            }
        }
    }
}

// UIKit wrapper for using the device camera
struct CameraImagePicker: UIViewControllerRepresentable {
    var onImagePicked: (UIImage) -> Void
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.sourceType = .camera
        picker.delegate = context.coordinator
        picker.allowsEditing = true
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) { }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(self)
    }
    
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        let parent: CameraImagePicker
        
        init(_ parent: CameraImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let image = info[.editedImage] as? UIImage ?? info[.originalImage] as? UIImage {
                parent.onImagePicked(image)
            }
            picker.dismiss(animated: true)
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            picker.dismiss(animated: true)
        }
    }
}

#Preview {
    ContentView()
}

