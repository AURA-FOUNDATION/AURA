import SwiftUI

// Onboarding with 3 slides. Replace image names (onboarding_1/2/3) with your sketch/guide.
struct OnboardingView: View {
    @Binding var hasSeenOnboarding: Bool
    @State private var page: Int = 0
    
    var body: some View {
        VStack {
            TabView(selection: $page) {
                OnboardingSlide(
                    title: "Add Your Items",
                    subtitle: "Use + to import clothes. Default items are preloaded.",
                    imageName: "onboarding_1",
                    fallbackSystem: "plus.circle"
                ).tag(0)
                
                OnboardingSlide(
                    title: "Matching",
                    subtitle: "Swipe through tops, bottoms, and shoes to visualize looks.",
                    imageName: "onboarding_2",
                    fallbackSystem: "wand.and.stars"
                ).tag(1)
                
                OnboardingSlide(
                    title: "Album & Edit",
                    subtitle: "Tap items to change category or delete from closet.",
                    imageName: "onboarding_3",
                    fallbackSystem: "square.grid.2x2"
                ).tag(2)
            }
            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .always))
            
            Button(action: {
                hasSeenOnboarding = true
            }) {
                Text("Got it")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .frame(height: 50)
                    .background(AppTheme.primary)
                    .cornerRadius(14)
                    .padding(.horizontal)
            }
            .padding(.bottom, 16)
        }
        .padding(.top, 20)
    }
}

private struct OnboardingSlide: View {
    let title: String
    let subtitle: String
    let imageName: String
    let fallbackSystem: String
    
    var body: some View {
        VStack(spacing: 20) {
            Spacer()
            onboardingImage
                .resizable()
                .scaledToFit()
                .frame(maxHeight: 260)
                .shadow(radius: 6)
                .padding(.horizontal, 30)
            
            Text(title)
                .font(.title2)
                .fontWeight(.semibold)
                .foregroundColor(AppTheme.primary)
            
            Text(subtitle)
                .font(.subheadline)
                .multilineTextAlignment(.center)
                .foregroundColor(.gray)
                .padding(.horizontal, 24)
            Spacer()
        }
    }
    
    private var onboardingImage: Image {
        if let ui = UIImage(named: imageName) {
            return Image(uiImage: ui)
        } else {
            return Image(systemName: fallbackSystem)
        }
    }
}


