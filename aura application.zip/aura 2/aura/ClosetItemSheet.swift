import SwiftUI

struct ClosetItemSheet: View {
    let item: ClothingItem
    @Binding var selectedCategory: ClothCategory
    var onChangeCategory: (ClothCategory) -> Void
    var onDelete: () -> Void
    var onDone: () -> Void
    @Environment(\.dismiss) private var dismiss
    
    var body: some View {
        NavigationView {
            VStack(spacing: 20) {
                Image(uiImage: item.image)
                    .resizable()
                    .scaledToFit()
                    .frame(height: 300)
                    .cornerRadius(16)
                    .shadow(radius: 10)
                    .padding()
                
                Picker("Category", selection: $selectedCategory) {
                    ForEach(ClothCategory.allCases, id: \.self) { cat in
                        Text(cat.rawValue).tag(cat)
                    }
                }
                .pickerStyle(.segmented)
                .padding(.horizontal)
                
                Spacer()
                
                Button(role: .destructive) {
                    onDelete()
                    onDone()
                    dismiss()
                } label: {
                    Label("Delete Item", systemImage: "trash")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(.red)
                .padding(.horizontal)
                
                Button(action: {
                    onChangeCategory(selectedCategory)
                    onDone()
                    dismiss()
                }) {
                    Text("Done")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                .tint(AppTheme.primary)
                .padding([.horizontal, .bottom])
            }
            .navigationTitle("Item Options")
            .navigationBarTitleDisplayMode(.inline)
        }
    }
}
