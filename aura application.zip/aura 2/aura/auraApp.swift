//
//  auraApp.swift
//  aura
//
//  Created by AFP FED 25 on 05/12/25.
//

import SwiftUI

@main
struct auraApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
