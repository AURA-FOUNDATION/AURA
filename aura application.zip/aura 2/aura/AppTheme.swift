import SwiftUI

// MARK: - CONFIG & THEME
struct AppTheme {
    // پس‌زمینه خیلی روشن
    static let bg = Color(red: 0.98, green: 0.98, blue: 0.99)
    
    // رنگ اصلی برند: #760D0D
    static let primary = Color(
        red: 118.0 / 255.0,
        green: 13.0 / 255.0,
        blue: 13.0 / 255.0
    )
    
    // رنگ ثانویه برای توضیحات
    static let secondary = Color.gray
}
