import SwiftUI

// MARK: - MODELS
enum ClothCategory: String, CaseIterable, Codable {
    case top = "Top"
    case bottom = "Bottom"
    case shoes = "Shoes"
}

struct ClothingItem: Identifiable, Hashable {
    let id: UUID
    let image: UIImage
    let category: ClothCategory
    
    init(image: UIImage, category: ClothCategory, id: UUID = UUID()) {
        self.id = id
        self.image = image
        self.category = category
    }
}

// مدل قابل ذخیره‌سازی برای نگه‌داشتن لباس‌ها در UserDefaults
struct StoredClothingItem: Codable {
    let id: UUID
    let imageData: Data
    let category: ClothCategory
}

// مدل برای visualize های save شده
struct SavedLook: Identifiable, Codable {
    let id: UUID
    let topItemId: UUID?
    let bottomItemId: UUID?
    let shoesItemId: UUID?
    let createdAt: Date
    
    init(topItemId: UUID?, bottomItemId: UUID?, shoesItemId: UUID?) {
        self.id = UUID()
        self.topItemId = topItemId
        self.bottomItemId = bottomItemId
        self.shoesItemId = shoesItemId
        self.createdAt = Date()
    }
    
    init(id: UUID, topItemId: UUID?, bottomItemId: UUID?, shoesItemId: UUID?, createdAt: Date) {
        self.id = id
        self.topItemId = topItemId
        self.bottomItemId = bottomItemId
        self.shoesItemId = shoesItemId
        self.createdAt = createdAt
    }
}
