import SwiftUI
import Combine
import UIKit

// MARK: - ENGINE (VIEW MODEL)
class AuraEngine: ObservableObject {
    @Published var items: [ClothingItem] = []
    @Published var savedLooks: [SavedLook] = []
    
    @Published var topIndex: Int = 0
    @Published var bottomIndex: Int = 0
    @Published var shoeIndex: Int = 0
    
    init() {
        loadPersistedItems()
        loadSavedLooks()
        seedDefaultsIfNeeded()
    }
    
    func getItems(for category: ClothCategory) -> [ClothingItem] {
        items.filter { $0.category == category }
    }
    
    func addItem(image: UIImage, category: ClothCategory) {
        let newItem = ClothingItem(image: image, category: category)
        items.insert(newItem, at: 0)
        resetIndexIfNeeded(for: category)
        persistItems()
    }
    
    func deleteItem(_ item: ClothingItem) {
        guard let index = items.firstIndex(of: item) else { return }
        items.remove(at: index)
        let categoryItems = getItems(for: item.category)
        switch item.category {
        case .top: if topIndex >= categoryItems.count { topIndex = max(0, categoryItems.count - 1) }
        case .bottom: if bottomIndex >= categoryItems.count { bottomIndex = max(0, categoryItems.count - 1) }
        case .shoes: if shoeIndex >= categoryItems.count { shoeIndex = max(0, categoryItems.count - 1) }
        }
        persistItems()
    }
    
    func changeCategory(for item: ClothingItem, to newCategory: ClothCategory) {
        guard let index = items.firstIndex(of: item) else { return }
        let updated = ClothingItem(image: item.image, category: newCategory, id: item.id)
        items.remove(at: index)
        items.insert(updated, at: 0)
        resetIndexIfNeeded(for: newCategory)
        persistItems()
    }
    
    func getCurrentTop() -> ClothingItem? { item(at: topIndex, in: .top) }
    func getCurrentBottom() -> ClothingItem? { item(at: bottomIndex, in: .bottom) }
    func getCurrentShoes() -> ClothingItem? { item(at: shoeIndex, in: .shoes) }
    
    private func item(at idx: Int, in category: ClothCategory) -> ClothingItem? {
        let list = getItems(for: category)
        guard !list.isEmpty, idx < list.count else { return nil }
        return list[idx]
    }
    
    private func resetIndexIfNeeded(for category: ClothCategory) {
        switch category {
        case .top: topIndex = 0
        case .bottom: bottomIndex = 0
        case .shoes: shoeIndex = 0
        }
    }
    
    // MARK: - Persistence
    private let storageKey = "AuraClothingItems"
    
    private func persistItems() {
        let stored: [StoredClothingItem] = items.compactMap { item in
            guard let data = item.image.jpegData(compressionQuality: 0.9) else { return nil }
            return StoredClothingItem(id: item.id, imageData: data, category: item.category)
        }
        if let encoded = try? JSONEncoder().encode(stored) {
            UserDefaults.standard.set(encoded, forKey: storageKey)
        }
    }
    
    private func loadPersistedItems() {
        guard let data = UserDefaults.standard.data(forKey: storageKey),
              let stored = try? JSONDecoder().decode([StoredClothingItem].self, from: data) else {
            return
        }
        
        self.items = stored.compactMap { storedItem in
            guard let image = UIImage(data: storedItem.imageData) else { return nil }
            return ClothingItem(image: image, category: storedItem.category, id: storedItem.id)
        }
    }
    
    private func seedDefaultsIfNeeded() {
        let key = "AuraDefaultsSeeded"
        guard !UserDefaults.standard.bool(forKey: key),
              items.isEmpty else { return }
        
        let seedImages: [(String, ClothCategory)] = [
            ("default_boots", .shoes),
            ("default_sneakers", .shoes),
            ("default_pants", .bottom),
            ("default_brown_tshirt", .top),
            ("default_blazer", .top),
            ("default_ny_cropped", .top),
            ("default_polo", .top),
            ("default_denim_jacket", .top)
        ]
        
        for (name, category) in seedImages {
            if let img = UIImage(named: name) {
                addItem(image: img, category: category)
            }
        }
        
        UserDefaults.standard.set(true, forKey: key)
    }
    
    // MARK: - Saved Looks Management
    private let savedLooksKey = "AuraSavedLooks"
    
    func saveCurrentLook() {
        let topId = getCurrentTop()?.id
        let bottomId = getCurrentBottom()?.id
        let shoesId = getCurrentShoes()?.id
        
        let newLook = SavedLook(
            topItemId: topId,
            bottomItemId: bottomId,
            shoesItemId: shoesId
        )
        
        savedLooks.insert(newLook, at: 0)
        persistSavedLooks()
    }
    
    func deleteSavedLook(_ look: SavedLook) {
        savedLooks.removeAll { $0.id == look.id }
        persistSavedLooks()
    }
    
    func updateSavedLook(_ look: SavedLook, topItemId: UUID?, bottomItemId: UUID?, shoesItemId: UUID?) {
        guard let index = savedLooks.firstIndex(where: { $0.id == look.id }) else { return }
        let updated = SavedLook(id: look.id, topItemId: topItemId, bottomItemId: bottomItemId, shoesItemId: shoesItemId, createdAt: look.createdAt)
        savedLooks[index] = updated
        persistSavedLooks()
    }
    
    func getItem(by id: UUID) -> ClothingItem? {
        items.first { $0.id == id }
    }
    
    private func persistSavedLooks() {
        if let encoded = try? JSONEncoder().encode(savedLooks) {
            UserDefaults.standard.set(encoded, forKey: savedLooksKey)
        }
    }
    
    private func loadSavedLooks() {
        guard let data = UserDefaults.standard.data(forKey: savedLooksKey),
              let looks = try? JSONDecoder().decode([SavedLook].self, from: data) else {
            return
        }
        self.savedLooks = looks
    }
}

